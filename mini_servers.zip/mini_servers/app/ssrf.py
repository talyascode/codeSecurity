"""
Flask Server
by Talya Gross

"""
import base64
import imghdr
import sys

import requests
from flask import Flask, request, render_template

app = Flask(__name__)


def is_image_data(data):
    """
    returning if the data is a image data
    """
    image_type = imghdr.what(None, h=data)
    return image_type != None


@app.route('/', methods=["GET", "POST"])
def user_input():
    """
    receiving the url, sending a get request to the requested server, and sending the result back to the client
    """
    if request.method == "POST":
        try:
            url = request.form.get("url")
            response = requests.get(url)
            data = response.content
            if is_image_data(data):
                # encode the image data as base64
                data_base64 = base64.b64encode(data).decode('utf-8')
                # return the base64-encoded string as a response
                return f'<img src="data:image/png;base64,{data_base64}"/>'
            else:
                return response.text
        except requests.exceptions.ConnectionError as err:
            return str(err)
    else:
        return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port= int(sys.argv[1]))
