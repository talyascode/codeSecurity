import os
filename = 'sql_server_fixed.py'
if os.path.isfile(filename):
    filepath = os.path.abspath(filename)
    print(filepath)
else:
    print('File not found')