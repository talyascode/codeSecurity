"""
Flask Server
by Talya Gross

vulnerable for sql injection
"""
import os
import sys

from flask import Flask, request, render_template
import sqlite3
SQL = "SELECT * FROM login WHERE name = '%s' AND password = '%s'"
HOST = "localhost"
USER = "user"
PASS = "serverDatabase1!"
DATABASE = "data.db"
NAME = "talya"
PASSWORD = "1234"

app = Flask(__name__)


def create_users_table():
    """Create an empty SQLite database file. Create a 'login' table in the specified SQLite database file."""
    conn = sqlite3.connect(DATABASE)
    conn.close()

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE login (name VARCHAR(255), password VARCHAR(255))")
    cursor.execute("INSERT INTO login (name, password) VALUES (?, ?)", (NAME, PASSWORD))

    conn.commit()
    conn.close()


def check_data(name, password):
    """
        connecting to the database and verifying the given data. vulnerable for sql injection
    """
    # os.remove(DATABASE)
    conn = None
    # create data
    if not os.path.exists(DATABASE):
        create_users_table()
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM login WHERE name = ? AND password = ?", (name, password))
        result = cursor.fetchone()

        if result:
            return True
        else:
            return False
    except sqlite3.Error as err:
        print(err)
    except sqlite3.Warning as err:
        print(err)
    finally:
        if conn:
            conn.close()


@app.route('/', methods=["GET", "POST"])
def user_input():
    """
    receiving the name and the password, verifying it and sending back the result to the client.
    """
    if request.method == "POST":
        try:
            name = request.form.get("name")
            password = request.form.get("pass")
            print(f"name: {name}, pass: {password}")
            result = check_data(name, password)
            if result:
                return "logged in successfully!"
            return "Error, name or password are not correct!"
        except ValueError:
            return "<h1>err: input is not a string</h1>"
    else:
        return render_template("input.html")


if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port= int(sys.argv[1]))
