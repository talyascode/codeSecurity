"""
Flask Server
by Talya Gross

"""
import base64
import imghdr
import sys

import requests
from flask import Flask, request, render_template
from flask_cors import CORS

NOT_ALLOW_LIST = ['172.17.0.5']
app = Flask(__name__)
CORS(app, origins=['http://localhost:3000'])


def is_image_data(data):
    """
    returning if the data is a image data
    """
    image_type = imghdr.what(None, h=data)
    return image_type != None


def is_allow(url):
    """
    checks if the url is allowed(in the allow list)
    """
    domain = url.split('//')[1].split('/')[0].split(':')[0]
    print(domain)
    return domain not in NOT_ALLOW_LIST


@app.route('/', methods=["GET", "POST"])
def user_input():
    """
    receiving the url, sending a get request to the requested server, and sending the result back to the client
    """
    if request.method == "POST":
        try:
            url = request.form.get("url")
            if is_allow(url):
                response = requests.get(url)
                data = response.content
                if is_image_data(data):
                    # encode the image data as base64
                    data_base64 = base64.b64encode(data).decode('utf-8')
                    # return the base64-encoded string as a response
                    return f'<img src="data:image/png;base64,{data_base64}"/>'
                else:
                    return response.text
            return  f'error: the url isnt allowed, pls enter a domain not from this list:{NOT_ALLOW_LIST}'
        except requests.exceptions.ConnectionError as err:
            return  str(err)
    else:
        return render_template("index.html")



if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port= int(sys.argv[1]))
